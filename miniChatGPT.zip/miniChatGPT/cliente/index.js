import { Comunicacion } from "./modules/comunicacion.js";
import { Grabacion } from "./modules/grabacion.js";

let grabacion = new Grabacion();
let comunicacion = new Comunicacion('localhost', 5500, grabacion.sendText.bind(grabacion));
