class Grabacion {
    constructor() {
        this.textarea = document.getElementById('textarea');
        this.recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
        this.initialize();
    }

    initialize() {
        const speak = document.getElementById('speak');
        speak.addEventListener('click', () => {
            this.startRecognition();
        });

        this.recognition.onresult = (e) => {
            this.handleResult(e);
        };
    }

    startRecognition() {
        this.recognition.start();
    }

    handleResult(event) {
        const transcript = event.results[0][0].transcript;
        this.textarea.innerHTML = transcript;
        this.sendText(this.textarea.innerHTML);
    }

    sendText(msgEnviar) {
        console.log('funcion para enviar');
        return msgEnviar;
    }
}

export { Grabacion };
