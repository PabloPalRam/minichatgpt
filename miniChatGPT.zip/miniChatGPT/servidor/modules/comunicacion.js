import { WebSocketServer } from 'ws';
// import { GenerativeAI } from './generativeAI.js';

class Comunicacion {
    constructor(port) {
        this.wss = new WebSocketServer({ port: port });
        // this.generativeAI = new GenerativeAI(); // Instancia de GenerativeAI
        
        this.wss.on('connection', (ws) => {
            console.log('Cliente conectado');

            // Manejar mensajes entrantes del cliente
            ws.on('message', (message) => {
                console.log('Mensaje recibido del cliente:', message);
        
                // Guardar el mensaje como prompt
                this.prompt = message;
        
                // Generar una respuesta utilizando GenerativeAI
                // const response = await this.generativeAI.generateResponse(message);
        
                // Enviar la respuesta al cliente
                // ws.send(response);
                console.log('Mensaje recibido:', this.prompt);
            });
        });
    }

    sendPrompt() {
        return this.prompt;
    }
}

export { Comunicacion };
