const OpenAI = require("openai");

class GenerativeAI {
    constructor() {
        this.openai = new OpenAI({
            apiKey: 'sk-proj-4g0681rM90CPiUX9mUTWT3BlbkFJW47N30EJ4wzsDSaDpsgU'
        });
    }

    async generateResponse(prompt) {
        try {
            const response = await this.openai.sendMessage(prompt);
            const generatedResponse = response.data.choices[0].message.content;
            console.log('Respuesta generada:', generatedResponse);
            return generatedResponse;
        } catch (error) {
            console.error('Error al generar respuesta:', error);
            return 'Lo siento, no pude generar una respuesta en este momento.';
        }
    }
    
}

export { GenerativeAI };
