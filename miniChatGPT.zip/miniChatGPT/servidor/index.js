// import { GenerativeAI } from "./modules/generativeAI.js";
import { Comunicacion } from "./modules/comunicacion.js";

// Crear una instancia de Comunicacion
let comunicacion = new Comunicacion(5500);

// Crear una instancia de GenerativeAI
// let AI = new GenerativeAI();

// const prompt = comunicacion.sendPrompt(); 
// AI.generateResponse(prompt); // Generar una respuesta utilizando el prompt
